var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import Customer from "../models/customerClass.js";
let acc = [];
// function to get data from db.json for validation
export function getData() {
    function gatherData() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Customers";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherData().then(response => {
        acc = response;
    }).catch(err => {
        console.log(err);
    });
}
window.onload = getData;
console.log(acc);
// Event handler for customer form submission
let customerForm = document.querySelector("#customerform");
customerForm === null || customerForm === void 0 ? void 0 : customerForm.addEventListener('submit', (addCust));
// Function for adding Customer
function addCust(e) {
    e.preventDefault();
    let custid = document.getElementById("custid");
    let name = document.getElementById("name");
    let email = document.getElementById("mail");
    let phn = document.getElementById("phn");
    if (phn.value.length != 10) {
        alert("10 digit number required");
        return;
    }
    console.log(acc);
    if (checkDuplicateName(acc, custid.value)) {
        alert("Duplicate customer id ");
        return;
    }
    else if (checkDuplicateEmail(acc, email.value)) {
        alert("Duplicate customer email ");
        return;
    }
    else if (checkDuplicatePhone(acc, phn.value)) {
        alert("Duplicate Phone number");
        return;
    }
    else {
        let customer = new Customer(custid.value, name.value, email.value, phn.value);
        console.log(customer);
        acc.push(customer);
        let data = JSON.stringify(customer);
        fetch("http://localhost:3000/Customers", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: data
        }).then(res => res.json())
            .then(result => console.log(result))
            .catch(err => console.log(err));
    }
    clear();
}
// function for clearing form inputs after submission
function clear() {
    let customerForm = document.querySelector("#customerform");
    customerForm.reset();
}
// function to validate form details
function checkDuplicateName(Account, custId) {
    let flag = false;
    for (let i = 0; i < Account.length; i++) {
        if (Account[i].customerId == custId) {
            flag = true;
        }
    }
    return flag;
}
function checkDuplicateEmail(Account, email) {
    let flag = false;
    for (let i = 0; i < Account.length; i++) {
        if (Account[i].customerEmailId == email) {
            flag = true;
        }
    }
    return flag;
}
function checkDuplicatePhone(Account, phone) {
    let flag = false;
    for (let i = 0; i < Account.length; i++) {
        if (Account[i].customerPhoneNo == phone) {
            flag = true;
        }
    }
    return flag;
}
//# sourceMappingURL=customer.js.map