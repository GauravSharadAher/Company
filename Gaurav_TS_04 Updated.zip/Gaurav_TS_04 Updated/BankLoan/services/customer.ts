import Customer from "../models/customerClass.js";

 let acc: Customer[] = [];

// function to get data from db.json for validation
export function getData() {
    async function gatherData() {
        let url = "http://localhost:3000/Customers";
        let result = await fetch(url);
        let data = await result.json();
        return data;
    }
    gatherData().then(response => {
        acc = response
    }).catch(err => {
        console.log(err);
    })
}
window.onload = getData;



  console.log(acc)

// Event handler for customer form submission
let customerForm = document.querySelector("#customerform") as HTMLFormElement
customerForm?.addEventListener('submit', (addCust));

// Function for adding Customer
function addCust(e: any) {
    e.preventDefault();
    let custid = document.getElementById("custid") as HTMLInputElement;
    let name = document.getElementById("name") as HTMLInputElement;
    let email = document.getElementById("mail") as HTMLInputElement;
    let phn = document.getElementById("phn") as HTMLInputElement;

    if (phn.value.length != 10) {
        alert("10 digit number required")
        return;
    }
    console.log(acc)
    if (checkDuplicateName(acc, custid.value)) {
        alert("Duplicate customer id ")
        return;
    } 
     else if(checkDuplicateEmail(acc,email.value)){
        alert("Duplicate customer email ");
        return;
    }
    else if(checkDuplicatePhone(acc,phn.value)){
        alert("Duplicate Phone number");
        return;
    }
    else {
        let customer = new Customer(custid.value, name.value, email.value, phn.value);
        console.log(customer)
        acc.push(customer);
        let data = JSON.stringify(customer);
        fetch("http://localhost:3000/Customers", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: data
        }).then(res => res.json())
            .then(result => console.log(result))
            .catch(err => console.log(err));
    }
    clear();

}

// function for clearing form inputs after submission
function clear() {
    let customerForm = document.querySelector("#customerform") as HTMLFormElement;
    customerForm.reset();

}

// function to validate form details
function checkDuplicateName(Account: Customer[], custId: string) :boolean{
    let flag = false;
    for (let i = 0; i < Account.length; i++) {
        if (Account[i].customerId == custId ) {
            flag = true;
        }
    }
    return flag;
}
function checkDuplicateEmail(Account: Customer[], email: string){
    let flag = false;
    for (let i = 0; i < Account.length; i++) {
        if (Account[i].customerEmailId == email ) {
            flag = true;
        }
    }
    return flag;
}
function checkDuplicatePhone(Account: Customer[], phone: string){
    let flag = false;
    for (let i = 0; i < Account.length; i++) {
        if (Account[i].customerPhoneNo == phone ) {
            flag = true;
        }
    }
    return flag;
}




