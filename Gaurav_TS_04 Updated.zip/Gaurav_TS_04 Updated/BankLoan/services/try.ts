class Loan1{
    private custId:string;
    public loanId:string;
    private loanType:string;
    private loanAmount:number;
    private loanApprovedDate:Date;
    constructor(custId:string,loanId:string, loanType:string,loanAmount:number,loanApprovedDate:Date){
        this.custId=custId;
        this.loanId=loanId;
        this.loanType=loanType;
        this.loanApprovedDate=new Date();
        this.loanAmount=loanAmount
    }

    get LoanAmt():number{
        return this.loanAmount;
    }
}
let akash=new Loan1("101","100","home",1000000,new Date());

class LoanTrans {
   public loanId:string;
   private deposit:number;
   private outstanding:number;
   constructor(loanId:string){
    this.loanId=loanId;
    this.deposit=0;
    this.outstanding=akash.LoanAmt;
   }
   display(){
    return `${this.loanId} ${this.outstanding} ${this.deposit}`
   }

   depositMoney(depositA:number){
        this.deposit+=depositA
        this.outstanding-=depositA;
   }
}
let aloan=new LoanTrans("101");
console.log(aloan.display());
aloan.depositMoney(100000);
console.log(aloan.display());




// when user clicks deposit then 
// first check the loanid present in loan transaction if yes then bring that obj 
// thn call that object  depositmoney method and  



