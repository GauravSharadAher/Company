import { Loan } from "../models/loanClass.js";
import Customer from "../models/customerClass.js";
import {RateOfInterest } from "../models/enumROI.js"
import { LoanType } from "../models/enumLoanType.js";

let searchButton = document.getElementById("searchbtn") as HTMLButtonElement;
searchButton.addEventListener("click", gridData);

let Loans:Array<Loan>=[];
let account:Customer[];


function fetchData() {

async function gatherDataLoan() {
        let url =  "http://localhost:3000/Loans";
        let result = await fetch(url);
        let data = await result.json();
      
        return data;
    }
    gatherDataLoan().then(response => {
        
        Loans.push(response)
        sessionStorage.setItem("loans",JSON.stringify(response));
        response.map((ele:Loan)=>{
            Loans.push(ele);
            
        })
        
    }).catch(err => {
        console.log(err);
    })


    async function gatherCust() {
        let url =  "http://localhost:3000/Customers";
        let result = await fetch(url);
        let data = await result.json();
      
        return data;
    }
    gatherCust().then(response => {
      account=response;
      sessionStorage.setItem("customer",JSON.stringify(response));
        
    }).catch(err => {
        console.log(err);
    })
   
}


window.onload=fetchData;




function gridData(){
//   
    let inputField = document.getElementById("userno") as HTMLInputElement
   
    let loandata=JSON.parse(sessionStorage.getItem("loans")!);
    let customer=JSON.parse(sessionStorage.getItem("customer")!); 
    //  let obj=[...loandata,...customer];
    console.log(Loans);
  
    try{
        if(loandata!=null){
    let id=customer.map((e:any)=>{
      if(e.customerId==inputField.value|| e.customerEmailId==inputField.value || e.customerPhoneNo==inputField.value){
        return e.customerId;
      }
    })
    let customerNo:string=id.filter((e:string)=> e)
    console.log(customerNo)
    DisplayTable(customerNo,loandata,inputField.value)
    }else{
        alert("no user")
        return;
    }
    }catch(err){
        console.log(err);
    }
}
function DisplayTable(customerno:string,loandata:any,input:any){
    let table = document.getElementById("table") as HTMLDivElement
    let data= loandata.filter((e:any)=>{
        return e.customerId==customerno || e.loanId==input 
    })
    if(data.length>0){
     table.innerHTML="";
   let grid= new gridjs.Grid({
             columns: [],
             sort: true,
             data: []
         }).render(document.getElementById('table'));
         grid.updateConfig({
            columns: ['customerId', 
            'loanAmount',
            {
                name: 'loanId',
                formatter: (cell:string, row:any) => {
                    const url = generateLoanIdUrl(cell);
                    return `<a href="${url}">${cell}</a>`;
                }
            },
            "loanStatus",
            "loanSanctionDate",
            "loanType"
            ,"annualInterestRate",
            "Deposits",
            "OutstandingAmount"],
            data: data,
          });
         grid.forceRender();
         return;
        }else{
            alert('')
            table.style.display="none"
        }
}


function generateLoanIdUrl(loanId: string): string {
    return `http://localhost:3000/Loans?loanId=${loanId}`;
}

