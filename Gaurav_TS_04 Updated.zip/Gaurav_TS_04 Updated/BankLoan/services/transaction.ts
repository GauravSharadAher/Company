import { Transaction } from "../models/TransactionClass.js";
import { Loan } from "../models/loanClass.js";

let Loans: Loan[] = [];
let TransactionDetails: Transaction[] = [];

function fetchData() {
    async function gatherDataLoan() {
        let url = "http://localhost:3000/Loans";
        let result = await fetch(url);
        let data = await result.json();
        return data;
    }

    gatherDataLoan()
        .then((response) => {
            Loans = response;
            console.log(Loans);
            getTransactionData();
        })
        .catch((err) => {
            console.log(err);
        });
}

window.onload = fetchData;

//  transaction details
function getTransactionData() {
    async function gatherTransaction() {
        let url = "http://localhost:3000/Transactions";
        let result = await fetch(url);
        let data = await result.json();
        return data;
    }

    gatherTransaction()
        .then((response) => {
            TransactionDetails = response;
        })
        .catch((err) => {
            console.log(err);
        });
}

let depositForm = document.querySelector("#depositForm") as HTMLFormElement;
depositForm.addEventListener('submit', depositMoney);

function depositMoney(e: any) {
    e.preventDefault();
    let lastLoanAmt:number = 0;
    let loanDetails = Loans;
    
    let transactionData = TransactionDetails;
    let loanNo = document.getElementById("loanno") as HTMLInputElement;
    let amountDeposit = document.getElementById("depamt") as HTMLInputElement;
    let refernceId = "REF" + Math.floor(Math.random() * 1000) + "ICIC";

    if (loanNo.value.trim() == "") {
        alert("Empty Loan no");
        return;
    } else if (parseInt(amountDeposit.value) <= 0) {
        alert("Enter valid Amount");
        return;
    } else {
        let flag = false;
        let lastBalanceAmt = transactionData.filter((e) => {
            return e.loanId == loanNo.value;
        });

        for (let i = 0; i < lastBalanceAmt.length; i++) {
            if (i == lastBalanceAmt.length - 1) {
                lastLoanAmt = lastBalanceAmt[i].balanceAmt;
            }
        }
        if(lastLoanAmt==0){
            alert("Loan amt paid and status is closed");
            return;
        }

        console.log(lastLoanAmt);
        if(lastLoanAmt<parseInt(amountDeposit.value)){
            alert("Money greater than remaining amt");
            return;
        }

      

        loanDetails.map((element) => {
            if (element.loanStatus == "Active" && element.loanId == loanNo.value) {
                alert("Money deposited successfully");
                flag = true;

                
                let transaction = new Transaction(refernceId, loanNo.value, parseInt(amountDeposit.value), 0);

                
                transaction.depositMoney(lastLoanAmt);

               
                let transactionData = JSON.stringify(transaction);


                fetch("http://localhost:3000/Transactions", {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: transactionData
                })
                    .then(res => res.json())
                    .then(result => console.log(result))
                    .catch(err => console.log(err));
            }

            
        });

        if (!flag) {
            alert("Wrong loan no");
            return;
        }
    }
}
