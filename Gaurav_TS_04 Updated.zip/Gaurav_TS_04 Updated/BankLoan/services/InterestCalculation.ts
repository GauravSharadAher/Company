// interestCalculator.ts

 import { Transaction } from "../models/TransactionClass.js";

// export function calculateInterestAndPost(transaction: Transaction, clearingDate: string) {
//     // Calculate interest until the clearing date
//     const dailyInterestRate = 0.01; // You can adjust this based on your actual interest rate
//     const currentDate = new Date().toLocaleDateString('en-GB');
//     const daysUntilClearing = Math.floor((new Date(clearingDate).getTime() - new Date(currentDate).getTime()) / (24 * 60 * 60 * 1000));

//     // Check if the balance has remained the same for the entire period
//     if (transaction.balanceAmt === transaction.debitAmt) {
//         const interestAmount = (transaction.balanceAmt * daysUntilClearing * dailyInterestRate * 365) / 100;

//         // Update debitAmt in the transaction
//         transaction.debitAmt = (transaction.debitAmt || 0) + interestAmount;
//     }

//     return transaction;
// }

let Transactions:Transaction[]=[];

function getTransactionData() {
    async function gatherTransaction() {
        let url = "http://localhost:3000/Transactions";
        let result = await fetch(url);
        let data = await result.json();
        return data;
    }

    gatherTransaction()
        .then((response) => {
            Transactions = response;
        })
        .catch((err) => {
            console.log(err);
        });
}
window.onload=getTransactionData;

export function interest(){
        let lastDATE:string='';
        let nextDate:string='';
        for(let i=0;i<Transactions.length-1;i++){
            let diff=parseInt(Transactions[i].depositDate.substring(0,2)) - parseInt(Transactions[i+1].depositDate.substring(0,2))

            let interest=diff*l

        }
}
