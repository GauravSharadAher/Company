var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { Transaction } from "../models/TransactionClass.js";
let Loans = [];
let TransactionDetails = [];
function fetchData() {
    function gatherDataLoan() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Loans";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherDataLoan()
        .then((response) => {
        Loans = response;
        console.log(Loans);
        getTransactionData();
    })
        .catch((err) => {
        console.log(err);
    });
}
window.onload = fetchData;
//  transaction details
function getTransactionData() {
    function gatherTransaction() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Transactions";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherTransaction()
        .then((response) => {
        TransactionDetails = response;
    })
        .catch((err) => {
        console.log(err);
    });
}
let depositForm = document.querySelector("#depositForm");
depositForm.addEventListener('submit', depositMoney);
function depositMoney(e) {
    e.preventDefault();
    let lastLoanAmt = 0;
    let loanDetails = Loans;
    let transactionData = TransactionDetails;
    let loanNo = document.getElementById("loanno");
    let amountDeposit = document.getElementById("depamt");
    let refernceId = "REF" + Math.floor(Math.random() * 1000) + "ICIC";
    if (loanNo.value.trim() == "") {
        alert("Empty Loan no");
        return;
    }
    else if (parseInt(amountDeposit.value) <= 0) {
        alert("Enter valid Amount");
        return;
    }
    else {
        let flag = false;
        let lastBalanceAmt = transactionData.filter((e) => {
            return e.loanId == loanNo.value;
        });
        for (let i = 0; i < lastBalanceAmt.length; i++) {
            if (i == lastBalanceAmt.length - 1) {
                lastLoanAmt = lastBalanceAmt[i].balanceAmt;
            }
        }
        if (lastLoanAmt == 0) {
            alert("Loan amt paid and status is closed");
            return;
        }
        console.log(lastLoanAmt);
        if (lastLoanAmt < parseInt(amountDeposit.value)) {
            alert("Money greater than remaining amt");
            return;
        }
        loanDetails.map((element) => {
            if (element.loanStatus == "Active" && element.loanId == loanNo.value) {
                alert("Money deposited successfully");
                flag = true;
                let transaction = new Transaction(refernceId, loanNo.value, parseInt(amountDeposit.value), 0);
                transaction.depositMoney(lastLoanAmt);
                let transactionData = JSON.stringify(transaction);
                fetch("http://localhost:3000/Transactions", {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: transactionData
                })
                    .then(res => res.json())
                    .then(result => console.log(result))
                    .catch(err => console.log(err));
            }
        });
        if (!flag) {
            alert("Wrong loan no");
            return;
        }
    }
}
//# sourceMappingURL=transaction.js.map