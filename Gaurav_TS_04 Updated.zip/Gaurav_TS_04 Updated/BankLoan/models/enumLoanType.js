export var LoanType;
(function (LoanType) {
    LoanType["Home"] = "Home";
    LoanType["Bussiness"] = "Bussiness";
    LoanType["Personal"] = "Personal";
})(LoanType || (LoanType = {}));
//# sourceMappingURL=enumLoanType.js.map