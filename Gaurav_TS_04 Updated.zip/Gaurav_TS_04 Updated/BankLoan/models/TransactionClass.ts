import { Loan } from "./loanClass";

export class Transaction{
    public loanId:string;
    private refernceId:string;
    private credit:number;
    public depositDate:string;
    private debitAmt? :number;
    private balanceAmt?:number;

    constructor(refernceId:string,loanId:string,credit:number,debitAmt?:number,balanceAmt?:number){
        this.depositDate=new Date().toLocaleDateString('en-GB');
        this.loanId=loanId;
        this.credit=credit;
        this.debitAmt=debitAmt
        this.balanceAmt=balanceAmt;
        this.refernceId=refernceId;
        //   this.depositMoney(this.lastBalance!,this.credit);
    }

    // get getLoanId(){
    //     return this.loanId;
    // }

    // get getRefernceId(){
    //     return this.refernceId;
    // }

    // get getDepositDate(){
    //     return this.depositDate;
    // }

    // get getBalnceAmt(){
    //    return this.balanceAmt;
    // }

    // get getCreditAmt(){
    //     return this.credit;
    // }

    // get getDebitAmt(){
    //     return this.debitAmt;
    // }

    // set setDebitAmt(debit:number){
    //     this.debitAmt=debit
    // }

    // set setBalance(balanceAmt:number){
    //     this.balanceAmt=balanceAmt
    // }


    depositMoney(lastBal: number) {
        if (lastBal <= 0) {
            this.balanceAmt = 0;
        }
        
        
        
        else {
            this.balanceAmt = lastBal - this.credit;
        }
    }

}