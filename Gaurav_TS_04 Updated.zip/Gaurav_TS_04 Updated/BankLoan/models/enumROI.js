export var RateOfInterest;
(function (RateOfInterest) {
    RateOfInterest[RateOfInterest["Home"] = 9] = "Home";
    RateOfInterest[RateOfInterest["Bussiness"] = 10] = "Bussiness";
    RateOfInterest[RateOfInterest["Personal"] = 12] = "Personal";
})(RateOfInterest || (RateOfInterest = {}));
//# sourceMappingURL=enumROI.js.map