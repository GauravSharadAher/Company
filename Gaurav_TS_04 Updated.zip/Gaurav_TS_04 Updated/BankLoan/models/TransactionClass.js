export class Transaction {
    constructor(refernceId, loanId, credit, debitAmt, balanceAmt) {
        this.depositDate = new Date().toLocaleDateString('en-GB');
        this.loanId = loanId;
        this.credit = credit;
        this.debitAmt = debitAmt;
        this.balanceAmt = balanceAmt;
        this.refernceId = refernceId;
        //   this.depositMoney(this.lastBalance!,this.credit);
    }
    // get getLoanId(){
    //     return this.loanId;
    // }
    // get getRefernceId(){
    //     return this.refernceId;
    // }
    // get getDepositDate(){
    //     return this.depositDate;
    // }
    // get getBalnceAmt(){
    //    return this.balanceAmt;
    // }
    // get getCreditAmt(){
    //     return this.credit;
    // }
    // get getDebitAmt(){
    //     return this.debitAmt;
    // }
    // set setDebitAmt(debit:number){
    //     this.debitAmt=debit
    // }
    // set setBalance(balanceAmt:number){
    //     this.balanceAmt=balanceAmt
    // }
    depositMoney(lastBal) {
        if (lastBal <= 0) {
            this.balanceAmt = 0;
        }
        else {
            this.balanceAmt = lastBal - this.credit;
        }
    }
}
//# sourceMappingURL=TransactionClass.js.map