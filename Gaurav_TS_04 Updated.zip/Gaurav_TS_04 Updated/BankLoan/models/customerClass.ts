

let counter=1;
export default class Customer {
    // private balance: number = 0;
    //  customerId: string;
    constructor(public customerId: string, public customerName: string, public customerEmailId: string, public customerPhoneNo: string) {
        // this.customerId = 
    }
    display(): string {
        return `${this.customerId} ${this.customerName} ${this.customerPhoneNo}`
    }
}