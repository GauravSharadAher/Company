var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let searchButton = document.getElementById("searchbtn");
searchButton.addEventListener("click", gridData);
let Loans = [];
let account;
function fetchData() {
    function gatherDataLoan() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Loans";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherDataLoan().then(response => {
        Loans.push(response);
        sessionStorage.setItem("loans", JSON.stringify(response));
        response.map((ele) => {
            Loans.push(ele);
        });
    }).catch(err => {
        console.log(err);
    });
    function gatherCust() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Customers";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherCust().then(response => {
        account = response;
        sessionStorage.setItem("customer", JSON.stringify(response));
    }).catch(err => {
        console.log(err);
    });
}
window.onload = fetchData;
function gridData() {
    //   
    let inputField = document.getElementById("userno");
    let loandata = JSON.parse(sessionStorage.getItem("loans"));
    let customer = JSON.parse(sessionStorage.getItem("customer"));
    //  let obj=[...loandata,...customer];
    console.log(Loans);
    try {
        if (loandata != null) {
            let id = customer.map((e) => {
                if (e.customerId == inputField.value || e.customerEmailId == inputField.value || e.customerPhoneNo == inputField.value) {
                    return e.customerId;
                }
            });
            let customerNo = id.filter((e) => e);
            console.log(customerNo);
            DisplayTable(customerNo, loandata, inputField.value);
        }
        else {
            alert("no user");
            return;
        }
    }
    catch (err) {
        console.log(err);
    }
}
function DisplayTable(customerno, loandata, input) {
    let table = document.getElementById("table");
    let data = loandata.filter((e) => {
        return e.customerId == customerno || e.loanId == input;
    });
    if (data.length > 0) {
        table.innerHTML = "";
        let grid = new gridjs.Grid({
            columns: [],
            sort: true,
            data: []
        }).render(document.getElementById('table'));
        grid.updateConfig({
            columns: ['customerId',
                'loanAmount',
                {
                    name: 'loanId',
                    formatter: (cell, row) => {
                        const url = generateLoanIdUrl(cell);
                        return `<a href="./AddCustomer.html">${cell}</a>`;
                    }
                },
                "loanStatus",
                "loanSanctionDate",
                "loanType",
                "annualInterestRate",
                "Deposits",
                "OutstandingAmount"],
            data: data,
        });
        grid.forceRender();
        return;
    }
    else {
        alert('');
        table.style.display = "none";
    }
}
function generateLoanIdUrl(loanId) {
    return `http://localhost:3000/Loans?loanId=${loanId}`;
}
export {};
//# sourceMappingURL=search.js.map