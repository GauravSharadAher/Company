// interestCalculator.ts
import { Loan } from "../models/loanClass.js";
import { Transaction } from "../models/TransactionClass.js";





let Transactions: Transaction[] = [];



async function getTransactionData() {

    let url = "http://localhost:3000/Transactions";
    let result = await fetch(url);
    let data = await result.json();

    return data;
}




async function interest(loanId: string) {
    console.log("in in")
    let LoanId = loanId;
    Transactions = await getTransactionData();
    console.log(Transactions)
    let loanObj = Transactions.filter((e) => {
        return e.loanId == LoanId;
    })
    console.log(loanObj)

    let startdate: any = loanObj[0].depositDate.split('/');
    let date: number = parseInt(startdate[0]);
    let monthDays = CalculateDays(startdate[1], startdate[2]);//31 days
    console.log(monthDays);

    let totalIntrest: number = 0;
    loanObj.forEach((e: Transaction, index) => {
        let interestAmount: number;
        let diff: number = 0;
        console.log(e.depositDate.substring(0, 2))
        if (parseInt(e.depositDate.substring(3, 5)) == parseInt(startdate[1]) && parseInt(e.depositDate.substring(0, 2)) <= monthDays) {
            diff = parseInt(e.depositDate.substring(0, 2)) - date;
            console.log(diff)
            console.log(e.balanceAmt + e.credit + "  " + diff + " " + e.loanRoi)
            interestAmount = ((e.balanceAmt + e.credit) * diff * e.loanRoi) / (365 * 100);
            console.log(interestAmount)
            totalIntrest += interestAmount;
            //  totalIntrest=(totalIntrest+interestAmount)
            date = parseInt(e.depositDate.substring(0, 2))
            console.log(date);


        }

        else {

            if (loanObj[index - 1].depositDate.substring(3, 5) != e.depositDate.substring(3, 5)) {
                date = monthDays;
                diff = date - parseInt(loanObj[index - 1].depositDate.substring(0, 2));
                interestAmount = (loanObj[index - 1].balanceAmt * diff * e.loanRoi) / (365 * 100);
                totalIntrest += interestAmount
                
                let transaction = new Transaction("BankCredit", loanId, 0, e.loanRoi, totalIntrest, loanObj[index - 1].balanceAmt + totalIntrest);
                let transactiondata = JSON.stringify(transaction);
                console.log(transaction)

                // fetch("http://localhost:3000/Transactions", {
                //     method: "POST",
                //     headers: {
                //         'Content-Type': 'application/json'
                //     },
                //     body: transactiondata
                
                // }).then(res => res.json())
                //     .then(result => console.log(result))
                //     .catch(err => console.log(err));

                //     if (
                //         index === loanObj.length - 1 ||
                //         e.depositDate.substring(3, 5) !==
                //           loanObj[index + 1].depositDate.substring(3, 5)
                //       ) {
                //         await addTransaction(newTransaction);
                //       }
              
                       return;
            }
            startdate[1] = e.depositDate.substring(3, 5);
            monthDays = CalculateDays(startdate[1], startdate[2])
            date = 0;
            interestAmount = 0;
            totalIntrest = 0;
            interest(loanId)


            // startdate[1] = e.depositDate.substring(3, 5);
            //  date = monthDays;
            //  diff =  date-parseInt(e.depositDate.substring(0, 2));
            //   take that element balance only and subtract with monthly end day
            // console.log('in else')
            // interestAmount = (loanObj[index-1].balanceAmt * diff * e.loanRoi) / (365 * 100);
            // totalIntrest += interestAmount;

        }// totalIntrest+=interest;
        // console.log(totalIntrest);
        // date=parseInt(e.depositDate);

        // console.log(totalIntrest);
    })
    console.log(totalIntrest)
}
interest("HICIC092");


function CalculateDays(month: number, year: number) {
    return new Date(month, year, 0).getDate();
}



// codef for inserting data



//     if (parseInt(e.depositDate.substring(0, 2)) == monthDays && parseInt(e.depositDate.substring(3, 5))= parseInt(startdate[1])){
// let transaction = new Transaction("BankCredit", loanId, 0, totalIntrest, e.loanRoi, e.balanceAmt + totalIntrest);

