
import { Loan } from "../models/loanClass.js";
import Customer from "../models/customerClass.js";
import { getData } from "./customer.js";
import {RateOfInterest } from "../models/enumROI.js"
import { LoanType } from "../models/enumLoanType.js";
import { Transaction } from "../models/TransactionClass.js";
let Loans:Loan[];
let account:Customer[]=[];
function getDataLoan() {
    async function gatherDataLoan() {
        let url =  "http://localhost:3000/Loans";
        let result = await fetch(url);
        let data = await result.json();
      
        return data;
    }
    gatherDataLoan().then(response => {
        Loans = response
        console.log(response)
        
    }).catch(err => {
        console.log(err);
    })

    async function gatherCust() {
        let url =  "http://localhost:3000/Customers";
        let result = await fetch(url);
        let data = await result.json();
      
        return data;
    }
    gatherCust().then(response => {
        account = response
        console.log(response)
        
    }).catch(err => {
        console.log(err);
    })
}
window.onload = getDataLoan;



let loanForm=document.querySelector("#loan") as HTMLFormElement
loanForm.addEventListener('submit',addLoan);

function addLoan(e:any){
    e.preventDefault();

    let accountNumber=document.getElementById("accNo") as HTMLInputElement
    let loanType=document.getElementById("loantype") as HTMLSelectElement
    let loanAmt=document.getElementById("loanAmt") as HTMLInputElement

    let loanAccountNo=loanType.value.substring(0,1) +"ICIC0"+Math.floor(Math.random()*100);
    let roiValue;
    
    let key: keyof typeof RateOfInterest;
    for (key in RateOfInterest) {
       roiValue;
        if(key==loanType.value){
            roiValue = parseInt(RateOfInterest[key]) ;
        }
    // roiValue=roiValue1;
       
    }
    
    
    if(accountNumber.value.trim()==""){
        alert("please enter valid Account number")
        return;
    }else if(parseInt(loanAmt.value) < 0){
        alert("Enter valid Amount");
        return;
    }else{
        let flag=false;
        for(let i=0;i<account.length;i++){
            if(account[i].customerId==accountNumber.value){
               let loan=new Loan(accountNumber.value, roiValue as number,parseInt(loanAmt.value),loanAccountNo,loanType.value as LoanType)
               let transaction= new Transaction('Bankcredit',loanAccountNo,0,roiValue as number,parseInt(loanAmt.value),parseInt(loanAmt.value));
                    alert("Loan sanctioned sucessfully")

                    // Transactions
                    flag=true;
                    Loans.push(loan);
                    console.log(loan);
                    let data = JSON.stringify(loan);
                    let transactiondata=JSON.stringify(transaction);

                    fetch("http://localhost:3000/Transactions", {
                        method: "POST",
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: transactiondata
                    }).then(res => res.json())
                        .then(result => console.log(result))
                        .catch(err => console.log(err));

                    fetch("http://localhost:3000/Loans", {
                        method: "POST",
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: data
                    }).then(res => res.json())
                        .then(result => console.log(result))
                        .catch(err => console.log(err));
                        return;
             }
        }
        if(!flag){
            alert("Account number is not present")
            clear();
            return;
         }
      
    }
}


function clear() {
    let customerloan = document.querySelector("#loan") as HTMLFormElement;
    customerloan.reset();

}