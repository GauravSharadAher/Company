export {};
//# sourceMappingURL=getTransactionData.js.map