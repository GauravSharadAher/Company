var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { Transaction } from "../models/TransactionClass.js";
let Transactions = [];
function getTransactionData() {
    return __awaiter(this, void 0, void 0, function* () {
        let url = "http://localhost:3000/Transactions";
        let result = yield fetch(url);
        let data = yield result.json();
        return data;
    });
}
function interest(loanId) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("in in");
        let LoanId = loanId;
        Transactions = yield getTransactionData();
        console.log(Transactions);
        let loanObj = Transactions.filter((e) => {
            return e.loanId == LoanId;
        });
        console.log(loanObj);
        let startdate = loanObj[0].depositDate.split('/');
        let date = parseInt(startdate[0]);
        let monthDays = CalculateDays(startdate[1], startdate[2]); //31 days
        console.log(monthDays);
        let totalIntrest = 0;
        loanObj.forEach((e, index) => {
            let interestAmount;
            let diff = 0;
            console.log(e.depositDate.substring(0, 2));
            if (parseInt(e.depositDate.substring(3, 5)) == parseInt(startdate[1]) && parseInt(e.depositDate.substring(0, 2)) <= monthDays) {
                diff = parseInt(e.depositDate.substring(0, 2)) - date;
                console.log(diff);
                console.log(e.balanceAmt + e.credit + "  " + diff + " " + e.loanRoi);
                interestAmount = ((e.balanceAmt + e.credit) * diff * e.loanRoi) / (365 * 100);
                console.log(interestAmount);
                totalIntrest += interestAmount;
                //  totalIntrest=(totalIntrest+interestAmount)
                date = parseInt(e.depositDate.substring(0, 2));
                console.log(date);
            }
            else {
                if (loanObj[index - 1].depositDate.substring(3, 5) != e.depositDate.substring(3, 5)) {
                    date = monthDays;
                    diff = date - parseInt(loanObj[index - 1].depositDate.substring(0, 2));
                    interestAmount = (loanObj[index - 1].balanceAmt * diff * e.loanRoi) / (365 * 100);
                    totalIntrest += interestAmount;
                    let transaction = new Transaction("BankCredit", loanId, 0, e.loanRoi, totalIntrest, loanObj[index - 1].balanceAmt + totalIntrest);
                    let transactiondata = JSON.stringify(transaction);
                    console.log(transaction);
                    // fetch("http://localhost:3000/Transactions", {
                    //     method: "POST",
                    //     headers: {
                    //         'Content-Type': 'application/json'
                    //     },
                    //     body: transactiondata
                    // }).then(res => res.json())
                    //     .then(result => console.log(result))
                    //     .catch(err => console.log(err));
                    //     if (
                    //         index === loanObj.length - 1 ||
                    //         e.depositDate.substring(3, 5) !==
                    //           loanObj[index + 1].depositDate.substring(3, 5)
                    //       ) {
                    //         await addTransaction(newTransaction);
                    //       }
                    return;
                }
                startdate[1] = e.depositDate.substring(3, 5);
                monthDays = CalculateDays(startdate[1], startdate[2]);
                date = 0;
                interestAmount = 0;
                totalIntrest = 0;
                interest(loanId);
                // startdate[1] = e.depositDate.substring(3, 5);
                //  date = monthDays;
                //  diff =  date-parseInt(e.depositDate.substring(0, 2));
                //   take that element balance only and subtract with monthly end day
                // console.log('in else')
                // interestAmount = (loanObj[index-1].balanceAmt * diff * e.loanRoi) / (365 * 100);
                // totalIntrest += interestAmount;
            } // totalIntrest+=interest;
            // console.log(totalIntrest);
            // date=parseInt(e.depositDate);
            // console.log(totalIntrest);
        });
        console.log(totalIntrest);
    });
}
interest("HICIC092");
function CalculateDays(month, year) {
    return new Date(month, year, 0).getDate();
}
// codef for inserting data
//     if (parseInt(e.depositDate.substring(0, 2)) == monthDays && parseInt(e.depositDate.substring(3, 5))= parseInt(startdate[1])){
// let transaction = new Transaction("BankCredit", loanId, 0, totalIntrest, e.loanRoi, e.balanceAmt + totalIntrest);
//# sourceMappingURL=InterestCalculation.js.map