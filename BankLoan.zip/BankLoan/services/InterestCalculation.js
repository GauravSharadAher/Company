var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { Transaction } from "../models/TransactionClass.js";
let Transactions = [];
function getTransactionData() {
    return __awaiter(this, void 0, void 0, function* () {
        let url = "http://localhost:3000/Transactions";
        let result = yield fetch(url);
        let data = yield result.json();
        return data;
    });
}
function interest(loanId) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log("in in");
        let LoanId = loanId;
        Transactions = yield getTransactionData();
        console.log(Transactions);
        let loanObj = Transactions.filter((e) => {
            return e.loanId == LoanId;
        });
        console.log(loanObj);
        let bankObjindex = 0;
        for (let index = 0; index < loanObj.length; index++) {
            if (loanObj[index].refernceId == "Bankcredit") {
                bankObjindex = index;
            }
        }
        console.log(bankObjindex + 'adfadfda');
        let startdate = loanObj[0].depositDate.split('/');
        let date = parseInt(startdate[0]);
        let monthDays = CalculateDays(parseInt(startdate[1]), parseInt(startdate[2])); //31 days
        console.log(monthDays);
        let totalIntrest = 0;
        let lastBalance;
        let rateOfI = loanObj[0].loanRoi;
        let interestAmount;
        let diff = 0;
        for (let i = bankObjindex; i < loanObj.length; i++) {
            if (parseInt(loanObj[i].depositDate.substring(3, 5)) == parseInt(startdate[1]) && parseInt(loanObj[i].depositDate.substring(0, 2)) <= monthDays) {
                diff = parseInt(loanObj[i].depositDate.substring(0, 2)) - date;
                console.log(diff);
                console.log(loanObj[i].balanceAmt + loanObj[i].credit + "  " + diff + " " + rateOfI);
                interestAmount = ((loanObj[i].balanceAmt + loanObj[i].credit) * diff * rateOfI) / (365 * 100);
                console.log(interestAmount);
                totalIntrest += interestAmount;
                //  totalIntrest=(totalIntrest+interestAmount)
                date = parseInt(loanObj[i].depositDate.substring(0, 2));
                console.log(date);
            }
            else {
                console.log("in else");
                if (loanObj[i - 1].depositDate.substring(3, 5) != loanObj[i].depositDate.substring(3, 5)) {
                    date = monthDays;
                    diff = date - parseInt(loanObj[i - 1].depositDate.substring(0, 2));
                    console.log(loanObj[i].balanceAmt + loanObj[i].credit + "  " + diff + " " + rateOfI);
                    lastBalance = loanObj[i - 1].balanceAmt;
                    interestAmount = lastBalance * diff * rateOfI / (365 * 100);
                    totalIntrest += interestAmount;
                    lastBalance = lastBalance + totalIntrest;
                    startdate[1] = loanObj[i].depositDate.substring(3, 5);
                    startdate[2] = loanObj[i].depositDate.substring(6);
                    startdate[0] = 0;
                    putData(loanId, totalIntrest, lastBalance, rateOfI);
                    break;
                }
                else {
                    break;
                }
            }
        }
        // loanObj.forEach((e: Transaction, index) => {
        //     console.log(e.depositDate.substring(0, 2))
        //     if (parseInt(e.depositDate.substring(3, 5)) == parseInt(startdate[1]) && parseInt(e.depositDate.substring(0, 2)) <= monthDays) {
        //         diff = parseInt(e.depositDate.substring(0, 2)) - date;
        //         console.log(diff)
        //         console.log(e.balanceAmt + e.credit + "  " + diff + " " + rateOfI)
        //         interestAmount = ((e.balanceAmt + e.credit) * diff * rateOfI) / (365 * 100);
        //         console.log(interestAmount)
        //         totalIntrest += interestAmount;
        //         //  totalIntrest=(totalIntrest+interestAmount)
        //         date = parseInt(e.depositDate.substring(0, 2))
        //         console.log(date);
        //     }
        //     else {
        //         console.log("in else")
        //         if (loanObj[index - 1].depositDate.substring(3, 5) != e.depositDate.substring(3, 5)) {
        //             date = monthDays;
        //             diff = date - parseInt(loanObj[index - 1].depositDate.substring(0, 2));
        //             console.log(e.balanceAmt + e.credit + "  " + diff + " " + rateOfI)
        //             lastBalance = loanObj[index - 1].balanceAmt
        //             interestAmount = lastBalance * diff * rateOfI / (365 * 100);
        //             totalIntrest += interestAmount
        //             lastBalance=lastBalance+totalIntrest;
        //             startdate[1]=e.depositDate.substring(3,5);
        //             startdate[2]=e.depositDate.substring(6);
        //             startdate[0]=0;
        //             //  putData(loanId,totalIntrest,lastBalance as number,rateOfI);
        //         }
        //             // diff=monthDays-parseInt(e.depositDate.substring(0,2));
        //             // interestAmount = (e.balanceAmt  * diff * rateOfI) / (365 * 100);
        //             // totalIntrest += interestAmount;
        //     }
        // })
        console.log(lastBalance + "last");
        console.log(totalIntrest);
    });
}
interest("HICIC092");
function CalculateDays(month, year) {
    return new Date(month, year, 0).getDate();
}
// codef for inserting data
//     if (parseInt(e.depositDate.substring(0, 2)) == monthDays && parseInt(e.depositDate.substring(3, 5))= parseInt(startdate[1])){
// let transaction = new Transaction("BankCredit", loanId, 0, totalIntrest, e.loanRoi, e.balanceAmt + totalIntrest);
// startdate[1] = e.depositDate.substring(3, 5);
// monthDays = CalculateDays(startdate[1], startdate[2])
// date = 0;
// interestAmount = 0;
// totalIntrest = 0;
// interest(loanId)
// startdate[1] = e.depositDate.substring(3, 5);
//  date = monthDays;
//  diff =  date-parseInt(e.depositDate.substring(0, 2));
//   take that element balance only and subtract with monthly end day
// console.log('in else')
// interestAmount = (loanObj[index-1].balanceAmt * diff * e.loanRoi) / (365 * 100);
// totalIntrest += interestAmount;
// totalIntrest+=interest;
// console.log(totalIntrest);
// date=parseInt(e.depositDate);
function putData(loanId, totalInterest, lastBalance, rateOfI) {
    let transaction = new Transaction("BankCredit", loanId, 0, rateOfI, totalInterest, lastBalance);
    let transactiondata = JSON.stringify(transaction);
    console.log(transaction);
    fetch("http://localhost:3000/Transactions", {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: transactiondata
    }).then(res => res.json())
        .then(result => console.log(result))
        .catch(err => console.log(err));
    return;
}
//# sourceMappingURL=InterestCalculation.js.map