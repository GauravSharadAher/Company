var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
let fileExtension = document.getElementById("excel");
let pdf = document.getElementById("pdf");
let searchButton = document.getElementById("searchbtn");
searchButton.addEventListener("click", DisplayTable);
let Transactions = [];
function getTransactionData() {
    return __awaiter(this, void 0, void 0, function* () {
        let url = "http://localhost:3000/Transactions";
        let result = yield fetch(url);
        let data = yield result.json();
        return data;
    });
}
function DisplayTable() {
    return __awaiter(this, void 0, void 0, function* () {
        Transactions = yield getTransactionData();
        let table = document.getElementById("table");
        let inputField = document.getElementById("userno");
        let data = Transactions.filter((e) => {
            return e.loanId == inputField.value;
        });
        if (data.length > 0) {
            table.innerHTML = "";
            let grid = new gridjs.Grid({
                columns: [],
                data: []
            }).render(document.getElementById('table'));
            grid.updateConfig({
                columns: ['depositDate',
                    'refernceId',
                    "debitAmt",
                    "credit",
                    "balanceAmt"
                ],
                data: data,
            });
            grid.forceRender();
            return;
        }
        else {
            alert('No user for given number');
            table.style.display = "none";
        }
    });
}
fileExtension.addEventListener("click", () => {
    var wb = XLSX.utils.table_to_book(document.querySelector(".gridjs-table"));
    XLSX.writeFile(wb, "Statement.xlsx");
});
pdf.addEventListener('click', () => {
    let element = document.querySelector(".gridjs-table");
    let opt = {
        margin: 10,
        filename: "Statemet.pdf",
        image: { type: 'jpeg', quality: 1 },
        html2canvas: { dpi: 300, letterRendering: true, width: 1080, height: 1920 },
        jsPDF: { unit: 'mm', format: 'a', orientation: 'landscape' },
        pagebreak: { mode: ['avoid-all', 'css'] }
    };
    html2pdf(element, opt);
});
export {};
//# sourceMappingURL=statement.js.map