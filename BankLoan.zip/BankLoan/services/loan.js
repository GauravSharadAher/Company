var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { Loan } from "../models/loanClass.js";
import { RateOfInterest } from "../models/enumROI.js";
import { Transaction } from "../models/TransactionClass.js";
let Loans;
let account = [];
function getDataLoan() {
    function gatherDataLoan() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Loans";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherDataLoan().then(response => {
        Loans = response;
        console.log(response);
    }).catch(err => {
        console.log(err);
    });
    function gatherCust() {
        return __awaiter(this, void 0, void 0, function* () {
            let url = "http://localhost:3000/Customers";
            let result = yield fetch(url);
            let data = yield result.json();
            return data;
        });
    }
    gatherCust().then(response => {
        account = response;
        console.log(response);
    }).catch(err => {
        console.log(err);
    });
}
window.onload = getDataLoan;
let loanForm = document.querySelector("#loan");
loanForm.addEventListener('submit', addLoan);
function addLoan(e) {
    e.preventDefault();
    let accountNumber = document.getElementById("accNo");
    let loanType = document.getElementById("loantype");
    let loanAmt = document.getElementById("loanAmt");
    let loanAccountNo = loanType.value.substring(0, 1) + "ICIC0" + Math.floor(Math.random() * 100);
    let roiValue;
    let key;
    for (key in RateOfInterest) {
        roiValue;
        if (key == loanType.value) {
            roiValue = parseInt(RateOfInterest[key]);
        }
        // roiValue=roiValue1;
    }
    if (accountNumber.value.trim() == "") {
        alert("please enter valid Account number");
        return;
    }
    else if (parseInt(loanAmt.value) < 0) {
        alert("Enter valid Amount");
        return;
    }
    else {
        let flag = false;
        for (let i = 0; i < account.length; i++) {
            if (account[i].customerId == accountNumber.value) {
                let loan = new Loan(accountNumber.value, roiValue, parseInt(loanAmt.value), loanAccountNo, loanType.value);
                let transaction = new Transaction('Bankcredit', loanAccountNo, 0, roiValue, parseInt(loanAmt.value), parseInt(loanAmt.value));
                alert("Loan sanctioned sucessfully");
                // Transactions
                flag = true;
                Loans.push(loan);
                console.log(loan);
                let data = JSON.stringify(loan);
                let transactiondata = JSON.stringify(transaction);
                fetch("http://localhost:3000/Transactions", {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: transactiondata
                }).then(res => res.json())
                    .then(result => console.log(result))
                    .catch(err => console.log(err));
                fetch("http://localhost:3000/Loans", {
                    method: "POST",
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: data
                }).then(res => res.json())
                    .then(result => console.log(result))
                    .catch(err => console.log(err));
                return;
            }
        }
        if (!flag) {
            alert("Account number is not present");
            clear();
            return;
        }
    }
}
function clear() {
    let customerloan = document.querySelector("#loan");
    customerloan.reset();
}
//# sourceMappingURL=loan.js.map