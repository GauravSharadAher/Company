import { Transaction } from "../models/TransactionClass";


let fileExtension = document.getElementById("excel") as HTMLButtonElement;
let pdf=document.getElementById("pdf") as HTMLButtonElement;
let searchButton = document.getElementById("searchbtn") as HTMLButtonElement;
searchButton.addEventListener("click", DisplayTable);
let table = document.getElementById("table") as HTMLDivElement;
let inputField = document.getElementById("userno") as HTMLInputElement
let Transactions: Transaction[] = [];

async function getTransactionData() {

    let url = "http://localhost:3000/Transactions";
    let result = await fetch(url);
    let data = await result.json();

    return data;
}
let data:any;
async function DisplayTable() {

    Transactions = await getTransactionData();
   
    
     data = Transactions.filter((e: any) => {
        return e.loanId == inputField.value
    })
    if (data.length > 0) {
        table.innerHTML = "";
        let grid = new gridjs.Grid({
            columns: [],
            data: []
        }).render(document.getElementById('table'));
        grid.updateConfig({
            columns: ['depositDate',
                'refernceId',
                "debitAmt",
                "credit",
                "balanceAmt"
            ],
            data: data,
        });
        grid.forceRender();
        return;
    } else {
        alert('No user for given number')
        table.style.display = "none"
    }


  

}

fileExtension.addEventListener("click", () => {
    var ws = XLSX.utils.json_to_sheet(data);
    var wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    XLSX.writeFile(wb, "Statement.xlsx");
});




pdf.addEventListener('click',()=>{
    console.log("in pdf")
    let element=document.querySelector(".gridjs-table");
    let opt={
        margin:10,
        filename:"Statemet.pdf",
        image:        { type: 'jpeg', quality: 1 },
        html2canvas:  { dpi: 300, letterRendering: true, width: 1080, height: 1920},
        jsPDF:        { unit: 'mm', format: 'a', orientation: 'landscape' },
        pagebreak:    { mode: ['avoid-all', 'css'] }
    };
    html2pdf(element,opt);
})



