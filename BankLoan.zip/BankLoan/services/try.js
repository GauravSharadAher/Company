"use strict";
class Loan1 {
    constructor(custId, loanId, loanType, loanAmount, loanApprovedDate) {
        this.custId = custId;
        this.loanId = loanId;
        this.loanType = loanType;
        this.loanApprovedDate = new Date();
        this.loanAmount = loanAmount;
    }
    get LoanAmt() {
        return this.loanAmount;
    }
}
let akash = new Loan1("101", "100", "home", 1000000, new Date());
class LoanTrans {
    constructor(loanId) {
        this.loanId = loanId;
        this.deposit = 0;
        this.outstanding = akash.LoanAmt;
    }
    display() {
        return `${this.loanId} ${this.outstanding} ${this.deposit}`;
    }
    depositMoney(depositA) {
        this.deposit += depositA;
        this.outstanding -= depositA;
    }
}
let aloan = new LoanTrans("101");
console.log(aloan.display());
aloan.depositMoney(100000);
console.log(aloan.display());
// when user clicks deposit then 
// first check the loanid present in loan transaction if yes then bring that obj 
// thn call that object  depositmoney method and  
//# sourceMappingURL=try.js.map