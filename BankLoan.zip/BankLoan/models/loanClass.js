export class Loan {
    constructor(customerId, annualInterestRate, loanAmount, loanId, loanType) {
        this.customerId = customerId;
        this.annualInterestRate = annualInterestRate;
        this.loanAmount = loanAmount;
        this.loanId = loanId;
        this.loanType = loanType;
        this.loanStatus = "Active";
        this.loanSanctionDate = new Date().toLocaleDateString('en-GB');
    }
    get getcustId() {
        return this.customerId;
    }
    get getRateOfInterest() {
        return this.annualInterestRate;
    }
    get getLoanType() {
        return this.loanType;
    }
    get getLoanAmt() {
        return this.loanAmount;
    }
    // get getLoanId():string{
    //     return this.loanId;
    // }
    get getloanSanctionDate() {
        return this.loanSanctionDate;
    }
}
//# sourceMappingURL=loanClass.js.map