import { LoanType } from "./enumLoanType";
import { RateOfInterest } from "./enumROI";

export class Loan {
    public loanId: string;
    public loanType: LoanType;
    public loanStatus:"Active"|"Closed";
    public loanSanctionDate:string;
    constructor(public customerId: string, public annualInterestRate: RateOfInterest, public loanAmount: number, loanId: string, loanType: LoanType) {
        this.loanId = loanId;
        this.loanType = loanType;
        this.loanStatus="Active";
        this.loanSanctionDate=new Date().toLocaleDateString('en-GB');
    }
    get getcustId(): string {
        return this.customerId;
    }
    get getRateOfInterest(): number {
        return this.annualInterestRate;
    }
    get getLoanType(): string {
        return this.loanType;
    }
    get getLoanAmt():number{
        return this.loanAmount
    }
    // get getLoanId():string{
    //     return this.loanId;
    // }

    get getloanSanctionDate():string{
        return this.loanSanctionDate;
    }

   
    
   
}