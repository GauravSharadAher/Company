import { RateOfInterest } from "./enumROI";
import { Loan } from "./loanClass";

export class Transaction{
    public loanId:string;
    public refernceId:string;
    public credit:number;
    public depositDate:string;
    public debitAmt? :number;
    public balanceAmt?:number;
    public loanRoi:RateOfInterest

    constructor(refernceId:string,loanId:string,credit:number,loanRoi:RateOfInterest,debitAmt?:number,balanceAmt?:number,){
        this.depositDate=new Date().toLocaleDateString('en-GB');
        this.loanId=loanId;
        this.loanRoi=loanRoi;
        this.credit=credit;
        this.debitAmt=debitAmt
        this.balanceAmt=balanceAmt;
        this.refernceId=refernceId;
    
    }




    depositMoney(lastBal: number) {
        if (lastBal <= 0) {
            this.balanceAmt = 0;
        }
        
        
        
        else {
            this.balanceAmt = lastBal - this.credit;
        }
    }

}