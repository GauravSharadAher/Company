export enum RateOfInterest {
    Home = 9,
    Bussiness = 10,
    Personal = 12
}