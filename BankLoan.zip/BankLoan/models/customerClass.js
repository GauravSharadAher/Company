let counter = 1;
export default class Customer {
    // private balance: number = 0;
    //  customerId: string;
    constructor(customerId, customerName, customerEmailId, customerPhoneNo) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerEmailId = customerEmailId;
        this.customerPhoneNo = customerPhoneNo;
        // this.customerId = 
    }
    display() {
        return `${this.customerId} ${this.customerName} ${this.customerPhoneNo}`;
    }
}
//# sourceMappingURL=customerClass.js.map