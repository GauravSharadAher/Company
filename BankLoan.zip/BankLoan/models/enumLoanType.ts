export enum LoanType {
    Home = "Home",
    Bussiness = "Bussiness",
    Personal = "Personal"
}