export class Transaction {
    constructor(refernceId, loanId, credit, loanRoi, debitAmt, balanceAmt) {
        this.depositDate = new Date().toLocaleDateString('en-GB');
        this.loanId = loanId;
        this.loanRoi = loanRoi;
        this.credit = credit;
        this.debitAmt = debitAmt;
        this.balanceAmt = balanceAmt;
        this.refernceId = refernceId;
    }
    depositMoney(lastBal) {
        if (lastBal <= 0) {
            this.balanceAmt = 0;
        }
        else {
            this.balanceAmt = lastBal - this.credit;
        }
    }
}
//# sourceMappingURL=TransactionClass.js.map