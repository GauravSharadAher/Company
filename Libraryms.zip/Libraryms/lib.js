"use strict";
var Genre;
(function (Genre) {
    Genre["Fiction"] = "Fiction";
    Genre["NonFiction"] = "NonFiction";
    Genre["Biography"] = "Biography";
    Genre["History"] = "History";
    Genre["Science"] = "Science";
})(Genre || (Genre = {}));
function addBook(library, book) {
    console.log('added to ui');
    alert("Book Added SucessFully");
}
function clear() {
    let libraryForm = document.querySelector("#addBookForm");
    let checkField = document.getElementById("checkoutBook");
    let returnField = document.getElementById("returnBook");
    libraryForm.reset();
    checkField.value = "";
    returnField.value = "";
}
function searchByGenre(library, genre) {
    let bookArray = [];
    for (let i = 0; i < library.length; i++) {
        if (library[i].genre == genre) {
            bookArray.push(library[i]);
        }
    }
    return bookArray;
}
function checkoutBook(library, bookTitle) {
    let message = "";
    for (let i = 0; i < library.length; i++) {
        console.log(library[i].title);
        if (library[i].title == bookTitle && library[i].isAvailable) {
            console.log("in ans");
            library[i].isAvailable = false;
            message = "Book is Available and sucessfullt checked out";
            break;
        }
        if (!library[i].isAvailable && library[i].title == bookTitle) {
            console.log(2);
            message = "Book is already checked out";
            return message;
        }
        if (library[i].title != bookTitle) {
            console.log(3);
            message = "Book is not found in the library";
        }
    }
    return message;
}
function returnBook(library, bookTitle) {
    let message = "";
    for (let i = 0; i < library.length; i++) {
        if (!library[i].isAvailable && library[i].title == bookTitle) {
            library[i].isAvailable = true;
            message = "Book is sucessfully returned";
            console.log(message);
            break;
        }
        if (library[i].isAvailable && library[i].title == bookTitle) {
            message = "Book is not checked out (Already available)";
            console.log(message);
            return message;
        }
        if (library[i].title != bookTitle) {
            message = "Book not found in library";
            console.log(bookTitle);
            console.log(library[i].title);
        }
    }
    document.getElementById;
    return message;
}
let BookTransaction;
let libraryForm = document.querySelector('#addBookForm');
libraryForm.addEventListener('submit', (sub));
let l1 = [];
function sub(e) {
    let title = document.getElementById('title');
    let author = document.getElementById('author');
    let genre = document.getElementById('genre');
    let publishDate = document.getElementById('publishDate');
    let hardCover = document.getElementById('hardcover');
    let type;
    let boolOfSeller = false;
    let format;
    let bestSeller = document.getElementById('bestseller');
    if (bestSeller.checked) {
        boolOfSeller = true;
    }
    if (hardCover.checked) {
        // format=hardCover.value;
    }
    let book = { title: `${title.value}`, author: `${author.value}`, genre: Genre[genre.value], publishDate: `${publishDate.value}`, isAvailable: true, isBestseller: boolOfSeller };
    l1.push(book);
    console.log(l1);
    console.log(book);
    e.preventDefault();
    addBook(l1, book);
    clear();
}
function loadBook() {
    let book1 = { title: "The Great Gatsby", author: "F. Scott Fitzgerald", genre: Genre.Fiction, publishDate: "1925-04-10", isAvailable: true };
    let book2 = { title: "a", author: "Paulo Coelho", genre: Genre.Biography, publishDate: "1955-06-07", isAvailable: true };
    let book3 = { title: "A Man Called Ove", author: "Fredrik Backman,", genre: Genre.NonFiction, publishDate: "1925-04-10", isAvailable: true };
    l1 = [book1, book2, book3];
}
window.onload = loadBook;
let searchBook = document.getElementById('sbtn');
searchBook.onclick = () => {
    let tabledata = "";
    let findBook = document.getElementById("genreDropdown");
    let tablebody = document.getElementById("table-body");
    let table = document.getElementById("table");
    let bookArr = searchByGenre(l1, Genre[findBook.value]);
    console.log(bookArr);
    if (bookArr.length >= 1) {
        bookArr.map(el => {
            tabledata += `<tr>
            <td>${el.title}</td>
            <td>${el.author}</td>
            <td>${el.publishDate}</td>
            <td>${el.genre}</td>
            </tr>`;
            console.log(tabledata);
        });
        tablebody.innerHTML = tabledata;
        table.style.display = "block";
    }
    else {
        alert('NO BOOK PRESENT');
    }
    console.log(bookArr);
    clear();
};
let checkBook = document.getElementById('cbtn');
checkBook.onclick = () => {
    let title = document.getElementById("checkoutBook");
    console.log(title.value);
    let message = checkoutBook(l1, title.value.trim());
    console.log(l1);
    clear();
    alert(message);
};
let returnbook = document.getElementById("rbtn");
returnbook.onclick = () => {
    let title = document.getElementById("returnBook");
    let message = returnBook(l1, title.value.trim());
    clear();
    alert(message);
};
//# sourceMappingURL=lib.js.map