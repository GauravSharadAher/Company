enum Genre{
    Fiction="Fiction",
    NonFiction="NonFiction",
    Biography="Biography",
    History="History",
    Science="Science"
}

interface Book{
    title:string;
    author:string;
    genre:Genre;
    publishDate:string;
    isAvailable:boolean;
    isBestseller?:boolean;
    format?:'Hardcover'|'Paperback'|'Ebook';
    
}

function addBook(library:Library,book:Book){
    console.log('added to ui');
    alert("Book Added SucessFully");
   
}

function clear(){
    let libraryForm=document.querySelector("#addBookForm") as HTMLFormElement;
    let checkField=document.getElementById("checkoutBook") as HTMLInputElement
    let returnField=document.getElementById("returnBook") as HTMLInputElement
    libraryForm.reset();
    checkField.value="";
    returnField.value="";
}

function searchByGenre(library:Library,genre:Genre):Book[]{
    let bookArray:Book[]=[];
        for(let i=0;i<library.length;i++){
             if(library[i].genre==genre){
                bookArray.push(library[i]);
             }
        }
    
    return bookArray;
}


function checkoutBook(library:Library,bookTitle:string):string{
    let message:string="";
    for(let i=0;i<library.length;i++){
        console.log(library[i].title)
    
        if(library[i].title==bookTitle && library[i].isAvailable){
            console.log("in ans")
            library[i].isAvailable=false;
            message= "Book is Available and sucessfullt checked out"
            break;
        }
        if(!library[i].isAvailable && library[i].title==bookTitle){
            console.log(2)
            message="Book is already checked out";
            return message;
        }
        if(library[i].title!=bookTitle){
            console.log(3)
            message= "Book is not found in the library"
            
        }
    }
    return message;

}


function returnBook(library:Library,bookTitle:string):string{

    let message:string="";
    for(let i=0;i<library.length;i++){
        if(!library[i].isAvailable && library[i].title==bookTitle){
            library[i].isAvailable=true;
            message= "Book is sucessfully returned"
            console.log(message);
            break;
        } 
        if(library[i].isAvailable && library[i].title==bookTitle){
            message= "Book is not checked out (Already available)"
            console.log(message);
            return message;
        }
        if(library[i].title!=bookTitle){
            message= "Book not found in library"
            console.log(bookTitle);
            console.log(library[i].title);
        }
    }
    document.getElementById
    return message
    
}
type Library=Book[];

let BookTransaction:[ Book | string];

 let  libraryForm=document.querySelector('#addBookForm') as HTMLFormElement;
 libraryForm.addEventListener('submit',(sub));
let l1:Library=[];
function sub(e:any){
    let title=document.getElementById('title') as HTMLInputElement;
    let author=document.getElementById('author') as HTMLInputElement;
    let genre=document.getElementById('genre') as HTMLSelectElement;
    let publishDate=document.getElementById('publishDate') as HTMLInputElement;
    let hardCover=document.getElementById('hardcover') as HTMLInputElement;
    let type;
   let boolOfSeller:boolean=false;
    let format :"Hardcover"|"Ebook"|"Papercover";
    let bestSeller=document.getElementById('bestseller') as HTMLInputElement;
    if(bestSeller.checked){
         boolOfSeller=true;
    }

    
    if(hardCover.checked ){
        // format=hardCover.value;
    }
  
    let book:Book={title:`${title.value}`,author:`${author.value}`,genre:Genre[genre.value as keyof typeof Genre],publishDate:`${publishDate.value}`,isAvailable:true,isBestseller:boolOfSeller}
    l1.push(book);
    
    console.log(l1);
    console.log(book);
     e.preventDefault();
     addBook(l1,book);
     clear();

}



function loadBook(){
    let book1:Book={title:"The Great Gatsby",author:"F. Scott Fitzgerald",genre:Genre.Fiction,publishDate:"1925-04-10",isAvailable:true}
    let book2:Book={title:"a",author:"Paulo Coelho",genre:Genre.Biography,publishDate:"1955-06-07",isAvailable:true}
    let book3:Book={title:"A Man Called Ove",author:"Fredrik Backman,",genre:Genre.NonFiction,publishDate:"1925-04-10",isAvailable:true}
    l1=[book1,book2,book3];
}
window.onload=loadBook;




let searchBook=document.getElementById('sbtn') as HTMLButtonElement;
searchBook.onclick=()=>{
    let tabledata="";
    let findBook=document.getElementById("genreDropdown") as HTMLSelectElement;
    let tablebody=document.getElementById("table-body") as HTMLBodyElement
    let table=document.getElementById("table") as HTMLDivElement
            
          let bookArr:Array<Book>= searchByGenre(l1,Genre[findBook.value as keyof typeof Genre]);
          console.log(bookArr);
          if(bookArr.length>=1){
          bookArr.map(el=>{
            tabledata+=`<tr>
            <td>${el.title}</td>
            <td>${el.author}</td>
            <td>${el.publishDate}</td>
            <td>${el.genre}</td>
            </tr>`
            console.log(tabledata);
          });
          
          tablebody.innerHTML=tabledata
          table.style.display="block"
        }else{
            alert('NO BOOK PRESENT')
        }
          console.log(bookArr);
          clear();
          
}
let checkBook=document.getElementById('cbtn') as HTMLButtonElement
checkBook.onclick=()=>{
    let title=document.getElementById("checkoutBook") as HTMLInputElement;
    console.log(title.value);
    let message:string=checkoutBook(l1,title.value.trim())
    console.log(l1);
    clear()
    alert(message);
}
let returnbook=document.getElementById("rbtn") as HTMLButtonElement;
returnbook.onclick=()=>{
    let title=document.getElementById("returnBook") as HTMLInputElement;
    let message:string=returnBook(l1,title.value.trim())
    clear();
    alert(message);
    
}